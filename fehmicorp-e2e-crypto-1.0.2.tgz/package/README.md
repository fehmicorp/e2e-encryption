# 🔐 Fehmi End-to-End Crypto

**`@fehmicorp/e2e-crypto`** is a lightweight JavaScript SDK for implementing **end-to-end encrypted API communication** between client applications and servers.

The package encrypts request payloads on the client, securely transmits them to the server, decrypts them for processing, and encrypts responses before sending them back.

This ensures that **API payloads remain encrypted in transit**, preventing exposure even if network traffic is intercepted.

---

# 🚀 Features

* End-to-End encrypted API communication
* Hybrid encryption model (**RSA + AES-256**)
* Works with **Node.js backends and browser clients**
* Simple integration with REST APIs
* Secure payload encryption and decryption
* Minimal dependencies
* Open-source and lightweight

---

# 📦 Installation

Install the package using npm:

```bash
npm install @fehmicorp/e2e-crypto
```

---

# 🔑 Encryption Architecture

The library uses a **hybrid encryption system**:

1. Client generates a random **AES-256 key**
2. Payload is encrypted using **AES**
3. AES key is encrypted using **RSA public key**
4. Server decrypts AES key using **RSA private key**
5. Server decrypts payload
6. Response can be encrypted again before returning

```
Client
   │
   │ Encrypt Payload (AES)
   │ Encrypt AES Key (RSA Public Key)
   ▼
Encrypted Request
   ▼
Server
   │
   │ Decrypt AES Key (RSA Private Key)
   │ Decrypt Payload
   │ Process Request
   │ Encrypt Response
   ▼
Client decrypts response
```

---

# 📁 Basic Usage

## Client Side (Encrypt Request)

```javascript
import { encryptPayload } from "@fehmicorp/e2e-crypto"

const serverPublicKey = `-----BEGIN PUBLIC KEY-----
YOUR_PUBLIC_KEY
-----END PUBLIC KEY-----`

const payload = {
  username: "sameer",
  password: "secure-password"
}

const encrypted = encryptPayload(payload, serverPublicKey)

fetch("/api/login", {
  method: "POST",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify(encrypted)
})
```

---

## Server Side (Decrypt Request)

```javascript
import { decryptPayload } from "@fehmicorp/e2e-crypto"

app.post("/api/login", (req, res) => {

  const privateKey = process.env.PRIVATE_KEY

  const data = decryptPayload(req.body, privateKey)

  // Process request
  const result = {
    message: "Login successful"
  }

  res.json(result)
})
```

---

# 🔁 Encrypting Server Responses

You can optionally encrypt server responses before returning them to the client.

Example:

```javascript
import { encryptAES } from "@fehmicorp/e2e-crypto"

const encryptedResponse = encryptAES(responseData, aesKey)

res.json(encryptedResponse)
```

---

# 🔐 Security Design

| Layer        | Encryption      |
| ------------ | --------------- |
| Payload      | AES-256-CBC     |
| Key Exchange | RSA-2048        |
| IV           | Random 16 bytes |
| Encoding     | Base64          |

---

# 📦 Payload Format

Encrypted payload sent to server:

```json
{
  "key": "encrypted_aes_key",
  "payload": {
    "iv": "initialization_vector",
    "data": "encrypted_payload"
  }
}
```

---

# 🧩 API Reference

## encryptPayload(data, publicKey)

Encrypts payload using AES and encrypts the AES key using RSA.

Returns:

```json
{
  "key": "encrypted_key",
  "payload": {
    "iv": "...",
    "data": "..."
  }
}
```

---

## decryptPayload(body, privateKey)

Decrypts encrypted request payload.

Returns:

```json
{
  "username": "sameer",
  "password": "secure-password"
}
```

---

# ⚙️ Generate RSA Keys

You can generate keys using OpenSSL:

```bash
openssl genrsa -out private.pem 2048
openssl rsa -in private.pem -pubout -out public.pem
```

---

# 🧪 Example Workflow

```
Frontend
  │
  │ encryptPayload()
  ▼
Encrypted Request
  ▼
Backend
  │ decryptPayload()
  │ process logic
  ▼
Encrypted Response
  ▼
Frontend decrypt
```

---

# 📚 Supported Environments

* Node.js 16+
* Express.js
* React
* Next.js
* Vue
* Angular
* Any JavaScript runtime supporting crypto APIs

---

# 🛠 Development

Clone repository:

```bash
git clone https://github.com/fehmicorp/e2e-crypto
cd e2e-crypto
npm install
```

Run tests or development environment as needed.

---

# 📦 Publish to npm

Login:

```bash
npm login
```

Publish:

```bash
npm publish --access public
```

---

# 🧭 Roadmap

Planned improvements:

* Browser-native crypto support
* ECDH key exchange
* Forward secrecy
* Payload signing
* Replay attack protection
* Automatic key rotation
* TypeScript support

---

# 🤝 Contributing

Contributions are welcome.

1. Fork the repository
2. Create a feature branch
3. Commit changes
4. Submit a pull request

---

# 📄 License

MIT License

---

# 🌐 Maintained By

**Fehmi Corporation**

Building secure cloud and infrastructure tools.

GitHub
https://github.com/fehmicorp